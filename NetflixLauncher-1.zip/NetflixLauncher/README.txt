FLIX LAUNCHER 2.0 - Netflix-style Android TV launcher
Build: open in Android Studio > Build APK(s) > install on box (adb install app-debug.apk).
Set as home: press Home, pick "Flix Launcher" > Always, or
  adb shell cmd package set-home-activity com.netflixlauncher/.MainActivity

Features
- Hold OK on any app: add to My List, hide, app info, uninstall.
- System row > Launcher Settings: wallpaper (pick image), color themes, restore hidden apps,
  movie posters.
- Movie posters: get a free key at themoviedb.org/settings/api, paste it in Launcher Settings.
  Rows of real posters appear (Trending, Popular Movies/Shows); OK on a poster = trailer / find on Netflix.
