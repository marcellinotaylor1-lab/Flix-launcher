package com.netflixlauncher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import java.net.URL
import java.util.concurrent.Executors

class Prefs(c: Context) {
    private val sp = c.getSharedPreferences("flix", Context.MODE_PRIVATE)
    var favorites: List<String>
        get() = (sp.getString("fav", "") ?: "").split("\n").filter { it.isNotBlank() }
        set(v) { sp.edit().putString("fav", v.joinToString("\n")).apply() }
    var hidden: Set<String>
        get() = (sp.getStringSet("hidden", emptySet()) ?: emptySet()).toSet()
        set(v) { sp.edit().putStringSet("hidden", v).apply() }
    var wallpaperUri: String?
        get() = sp.getString("wall", null)
        set(v) { sp.edit().putString("wall", v).apply() }
    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v).apply() }
    var tmdbKey: String
        get() = sp.getString("tmdb", "") ?: ""
        set(v) { sp.edit().putString("tmdb", v).apply() }
}

object Themes {
    private val colors = listOf(
        intArrayOf(0xFF141414.toInt(), 0xFF4A0A12.toInt()),   // Netflix red
        intArrayOf(0xFF0B1026.toInt(), 0xFF1F3A8A.toInt()),   // Midnight blue
        intArrayOf(0xFF140A24.toInt(), 0xFF5B2A9E.toInt()),   // Purple
        intArrayOf(0xFF06150F.toInt(), 0xFF127A58.toInt()),   // Emerald
        intArrayOf(0xFF1A0B0B.toInt(), 0xFFB5481A.toInt())    // Sunset
    )
    val size: Int get() = colors.size
    fun drawable(i: Int) = GradientDrawable(GradientDrawable.Orientation.TL_BR, colors[i % colors.size])
}

object Img {
    private val cache = object : LruCache<String, Bitmap>(40 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val pool = Executors.newFixedThreadPool(4)
    private val main = Handler(Looper.getMainLooper())

    fun load(url: String?, iv: ImageView, onLoaded: (() -> Unit)? = null) {
        iv.tag = url
        iv.setImageDrawable(null)
        if (url == null) return
        cache.get(url)?.let { iv.setImageBitmap(it); onLoaded?.invoke(); return }
        pool.execute {
            try {
                val bmp = URL(url).openStream().use { BitmapFactory.decodeStream(it) }
                if (bmp != null) {
                    cache.put(url, bmp)
                    main.post { if (iv.tag == url) { iv.setImageBitmap(bmp); onLoaded?.invoke() } }
                }
            } catch (_: Exception) {}
        }
    }

    fun decodeUri(c: Context, uri: Uri): Bitmap? = try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (o.outWidth / s > 2000) s *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = s }
        c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
    } catch (e: Exception) { null }

    fun http(u: String): String {
        val c = URL(u).openConnection()
        c.connectTimeout = 8000; c.readTimeout = 8000
        return c.getInputStream().bufferedReader().use { it.readText() }
    }
}
