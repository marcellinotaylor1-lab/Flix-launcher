package com.netflixlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONObject

enum class Kind { APP, POSTER, ACTION }

data class Item(
    val label: String, val sub: String = "", val pkg: String = "",
    val intent: Intent? = null, val icon: Drawable? = null,
    val posterUrl: String? = null, val backdropUrl: String? = null,
    val kind: Kind = Kind.APP, val action: (() -> Unit)? = null
)
data class Row(val title: String, val items: List<Item>, val poster: Boolean = false)
class Cb(val focus: (Item) -> Unit, val click: (Item) -> Unit, val long: (Item) -> Unit)

class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var heroTitle: TextView
    private lateinit var heroSub: TextView
    private lateinit var heroIcon: ImageView
    private lateinit var heroBackdrop: ImageView
    private lateinit var wallpaper: ImageView
    private lateinit var rows: RecyclerView

    private var adapter: RowsAdapter? = null
    private var allApps = listOf<Item>()
    private val posterRows = mutableListOf<Row>()
    private var fetching = false
    private val reqWall = 42
    private val cb by lazy { Cb(::showHero, ::onClickItem, ::onLongItem) }

    private val streaming = setOf(
        "com.netflix.ninja", "com.netflix.mediaclient", "com.google.android.youtube.tv",
        "com.google.android.youtube.tvunplugged", "com.amazon.amazonvideo.livingroom",
        "com.disney.disneyplus", "com.wbd.stream", "com.hbo.hbonow", "com.hulu.plus",
        "com.apple.atve.androidtv.appletv", "com.plexapp.android", "tv.twitch.android.app",
        "com.spotify.tv.android", "org.videolan.vlc", "com.google.android.apps.youtube.music"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)
        heroTitle = findViewById(R.id.heroTitle)
        heroSub = findViewById(R.id.heroSub)
        heroIcon = findViewById(R.id.heroIcon)
        heroBackdrop = findViewById(R.id.heroBackdrop)
        wallpaper = findViewById(R.id.wallpaper)
        rows = findViewById(R.id.rows)
        rows.layoutManager = LinearLayoutManager(this)
        applyWallpaper()
    }

    override fun onResume() {
        super.onResume()
        render()
        fetchPosters()
    }

    // ---------- data ----------

    private fun loadApps() {
        val pm = packageManager
        val found = LinkedHashMap<String, Item>()
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val q = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (ri in pm.queryIntentActivities(q, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == packageName || found.containsKey(pkg)) continue
                val launch = Intent(Intent.ACTION_MAIN).addCategory(cat)
                    .setClassName(pkg, ri.activityInfo.name)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                val img = ri.activityInfo.loadBanner(pm) ?: ri.loadIcon(pm)
                found[pkg] = Item(ri.loadLabel(pm).toString(), pkg = pkg, intent = launch, icon = img)
            }
        }
        allApps = found.values.sortedBy { it.label.lowercase() }
    }

    private fun buildRows(): MutableList<Row> {
        loadApps()
        val visible = allApps.filter { it.pkg !in prefs.hidden }
        val list = mutableListOf<Row>()
        val favs = prefs.favorites.mapNotNull { p -> visible.find { it.pkg == p } }
        if (favs.isNotEmpty()) list += Row("My List", favs)
        list += posterRows
        val stream = visible.filter { it.pkg in streaming }
        if (stream.isNotEmpty()) list += Row("Popular on your TV", stream)
        list += Row("All Apps", visible)
        list += Row("System", listOf(
            Item("Launcher Settings", "Wallpaper, hidden apps, movie posters", kind = Kind.ACTION,
                icon = getDrawable(android.R.drawable.ic_menu_preferences), action = ::launcherSettings),
            Item("System Settings", "Wi-Fi, display, sound", kind = Kind.ACTION,
                icon = getDrawable(android.R.drawable.ic_menu_manage),
                action = { startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) })
        ))
        return list
    }

    private fun render() {
        val list = buildRows()
        adapter = RowsAdapter(list, cb)
        rows.adapter = adapter
        list.firstOrNull()?.items?.firstOrNull()?.let(::showHero)
    }

    private fun fetchPosters() {
        val key = prefs.tmdbKey
        if (key.isBlank() || fetching || posterRows.isNotEmpty()) return
        fetching = true
        Thread {
            val out = mutableListOf<Row>()
            val feeds = listOf("trending/all/week" to "Trending Now", "movie/popular" to "Popular Movies", "tv/popular" to "Popular Shows")
            for ((path, title) in feeds) {
                try {
                    val res = JSONObject(Img.http("https://api.themoviedb.org/3/$path?api_key=$key")).getJSONArray("results")
                    val items = mutableListOf<Item>()
                    for (i in 0 until res.length()) {
                        val o = res.getJSONObject(i)
                        val poster = o.optString("poster_path", "")
                        if (poster.isEmpty() || poster == "null") continue
                        val back = o.optString("backdrop_path", "")
                        val name = o.optString("title", o.optString("name", "Untitled"))
                        val rating = "★ %.1f".format(o.optDouble("vote_average", 0.0))
                        items += Item(
                            name, "$rating  •  ${o.optString("overview", "")}",
                            posterUrl = "https://image.tmdb.org/t/p/w342$poster",
                            backdropUrl = if (back.isNotEmpty() && back != "null") "https://image.tmdb.org/t/p/w780$back" else null,
                            kind = Kind.POSTER
                        )
                    }
                    if (items.isNotEmpty()) out += Row(title, items, poster = true)
                } catch (_: Exception) {}
            }
            runOnUiThread {
                fetching = false
                if (key == prefs.tmdbKey && out.isNotEmpty() && posterRows.isEmpty()) {
                    posterRows.addAll(out)
                    val a = adapter
                    if (a == null) render() else {
                        val idx = if (a.data.firstOrNull()?.title == "My List") 1 else 0
                        out.forEachIndexed { i, r -> a.insert(idx + i, r) }
                    }
                } else if (out.isEmpty()) toast("Couldn't load posters – check your TMDB key / internet")
            }
        }.start()
    }

    // ---------- UI ----------

    private fun showHero(item: Item) {
        heroTitle.text = item.label
        heroSub.text = if (item.sub.isNotEmpty()) item.sub
        else if (item.kind == Kind.APP) "Press OK to open  •  Hold OK for options" else ""
        Img.load(item.backdropUrl, heroBackdrop)
        heroIcon.setImageDrawable(if (item.kind == Kind.POSTER) null else item.icon)
    }

    private fun onClickItem(item: Item) {
        when (item.kind) {
            Kind.APP -> try { startActivity(item.intent) } catch (_: Exception) {
                packageManager.getLaunchIntentForPackage(item.pkg)?.let { startActivity(it) }
            }
            Kind.ACTION -> item.action?.invoke()
            Kind.POSTER -> posterDialog(item)
        }
    }

    private fun onLongItem(item: Item) { if (item.kind == Kind.APP) appDialog(item) }

    private fun dlg() = AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun appDialog(item: Item) {
        val fav = item.pkg in prefs.favorites
        val opts = arrayOf(if (fav) "Remove from My List" else "Add to My List", "Hide app", "App info", "Uninstall")
        dlg().setTitle(item.label).setItems(opts) { _, w ->
            when (w) {
                0 -> { prefs.favorites = if (fav) prefs.favorites - item.pkg else prefs.favorites + item.pkg; render() }
                1 -> { prefs.hidden = prefs.hidden + item.pkg; render(); toast("Hidden. Restore it in Launcher Settings") }
                2 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${item.pkg}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                3 -> startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${item.pkg}")))
            }
        }.show()
    }

    private fun posterDialog(item: Item) {
        val q = Uri.encode(item.label)
        dlg().setTitle(item.label).setItems(arrayOf("Watch trailer on YouTube", "Find on Netflix")) { _, w ->
            if (w == 0) view("https://www.youtube.com/results?search_query=$q+trailer", null)
            else view("https://www.netflix.com/search?q=$q", "com.netflix.ninja")
        }.show()
    }

    private fun view(url: String, pkg: String?) {
        try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (pkg != null) i.setPackage(pkg)
            startActivity(i)
        } catch (_: Exception) {
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            catch (_: Exception) { toast("No app found to open this") }
        }
    }

    // ---------- launcher settings ----------

    private fun launcherSettings() {
        val opts = arrayOf(
            "Change wallpaper (pick image)", "Next color theme", "Reset wallpaper",
            "Manage hidden apps (${prefs.hidden.size})",
            if (prefs.tmdbKey.isBlank()) "Enable movie posters (TMDB key)" else "Change / remove TMDB key"
        )
        dlg().setTitle("Launcher settings").setItems(opts) { _, w ->
            when (w) {
                0 -> pickWallpaper()
                1 -> { prefs.wallpaperUri = null; prefs.theme = (prefs.theme + 1) % Themes.size; applyWallpaper() }
                2 -> { prefs.wallpaperUri = null; prefs.theme = 0; applyWallpaper() }
                3 -> manageHidden()
                4 -> askKey()
            }
        }.show()
    }

    private fun pickWallpaper() {
        try {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT)
                .addCategory(Intent.CATEGORY_OPENABLE).setType("image/*")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), reqWall)
        } catch (_: Exception) { toast("No file picker on this box – use 'Next color theme' instead") }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqWall && resultCode == RESULT_OK) {
            val u = data?.data ?: return
            try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            prefs.wallpaperUri = u.toString()
            applyWallpaper()
        }
    }

    private fun applyWallpaper() {
        val u = prefs.wallpaperUri
        if (u == null) { wallpaper.setImageDrawable(Themes.drawable(prefs.theme)); return }
        Thread {
            val bmp = Img.decodeUri(this, Uri.parse(u))
            runOnUiThread {
                if (bmp != null) wallpaper.setImageBitmap(bmp)
                else wallpaper.setImageDrawable(Themes.drawable(prefs.theme))
            }
        }.start()
    }

    private fun manageHidden() {
        val hid = allApps.filter { it.pkg in prefs.hidden }
        if (hid.isEmpty()) { toast("No hidden apps"); return }
        val checked = BooleanArray(hid.size) { true }
        dlg().setTitle("Hidden apps (uncheck to show)")
            .setMultiChoiceItems(hid.map { it.label }.toTypedArray(), checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("Save") { _, _ ->
                val still = hid.filterIndexed { i, _ -> checked[i] }.map { it.pkg }.toSet()
                prefs.hidden = (prefs.hidden - hid.map { it.pkg }.toSet()) + still
                render()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun askKey() {
        val et = EditText(this).apply {
            setText(prefs.tmdbKey); hint = "TMDB API key (leave empty to remove)"
            inputType = InputType.TYPE_CLASS_TEXT; setTextColor(0xFFFFFFFF.toInt())
        }
        dlg().setTitle("Movie posters")
            .setMessage("Get a free API key at themoviedb.org/settings/api")
            .setView(et)
            .setPositiveButton("Save") { _, _ ->
                prefs.tmdbKey = et.text.toString().trim()
                posterRows.clear(); render(); fetchPosters()
            }.setNegativeButton("Cancel", null).show()
    }

    @Deprecated("Launcher must stay on home")
    override fun onBackPressed() { /* stay home */ }
}

// ---------- adapters ----------

class RowsAdapter(val data: MutableList<Row>, private val cb: Cb) : RecyclerView.Adapter<RowsAdapter.VH>() {
    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val title: TextView = v.findViewById(R.id.rowTitle)
        val list: RecyclerView = v.findViewById(R.id.rowList)
    }

    fun insert(i: Int, row: Row) { data.add(i, row); notifyItemInserted(i) }

    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
        val vh = VH(LayoutInflater.from(p.context).inflate(R.layout.item_row, p, false))
        vh.list.layoutManager = LinearLayoutManager(p.context, LinearLayoutManager.HORIZONTAL, false)
        return vh
    }

    override fun onBindViewHolder(h: VH, i: Int) {
        h.title.text = data[i].title
        h.list.adapter = CardsAdapter(data[i].items, data[i].poster, cb)
    }

    override fun getItemCount() = data.size
}

class CardsAdapter(private val items: List<Item>, private val poster: Boolean, private val cb: Cb) :
    RecyclerView.Adapter<CardsAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.appIcon)
        val name: TextView = v.findViewById(R.id.appName)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) = VH(
        LayoutInflater.from(p.context).inflate(if (poster) R.layout.item_poster else R.layout.item_app, p, false)
    )

    override fun onBindViewHolder(h: VH, i: Int) {
        val item = items[i]
        h.name.text = item.label
        if (item.kind == Kind.POSTER) {
            h.name.visibility = View.VISIBLE
            Img.load(item.posterUrl, h.icon) { h.name.visibility = View.GONE }
        } else {
            h.icon.tag = null
            h.icon.setImageDrawable(item.icon)
        }
        h.itemView.setOnClickListener { cb.click(item) }
        h.itemView.setOnLongClickListener { cb.long(item); true }
        h.itemView.setOnFocusChangeListener { v, focused ->
            val s = if (focused) 1.12f else 1f
            v.animate().scaleX(s).scaleY(s).setDuration(150).start()
            v.elevation = if (focused) 16f else 0f
            if (focused) cb.focus(item)
        }
    }

    override fun getItemCount() = items.size
}
